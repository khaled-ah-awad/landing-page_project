# Project-Title : Landing Page

# Created-By : Khaled-Ahmed-Awad 

The The Starter Code Was Cloned From :
https://github.com/udacity/fend/tree/refresh-2019/projects/landing-page


# Project-Description : 

[1] - Project Before Modifing :

It Was A Static Html Page Containing 3 Sections, Without Javascript, The Way To Move To Sections Was Scroll.

[2]- Project After Modifing :

It Becomes A Dynamic Page Containing 5 Sections, Javascript Added To It To Enable User To Interacte With The Page, User Can Scroll To Sections
By Click On The Navigation Items That Refers To The Sections.

# Project-Technologies :

    1. HTML
    2. CSS
    3. Javascript   
